<nav>
    <ul>
         <li><a href="dashboard.php">Home</a></li>
    
            <li><a href="login_admin.php">Admin</a></li>
            <li><a href="login_user.php">User</a></li>
             <li><a href="services.php">Services</a></li>
            <li><a href="help.php">Help</a></li>
    </ul>
</nav>
