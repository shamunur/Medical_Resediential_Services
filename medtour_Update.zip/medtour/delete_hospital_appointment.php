<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);

$sql = "DELETE FROM hospital_appointments WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: view_admin_hospital.php");
    exit;
} else {
    echo "Error deleting appointment: " . $conn->error;
}

$conn->close();
?>
