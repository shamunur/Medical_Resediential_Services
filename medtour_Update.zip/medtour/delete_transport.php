<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patient_id = intval($_GET['patient_id']);
$sql = "DELETE FROM transport_bookings WHERE patient_id = $patient_id";

if ($conn->query($sql) === TRUE) {
    echo "Transport booking deleted successfully.";
} else {
    echo "Error deleting booking: " . $conn->error;
}

$conn->close();
?>
