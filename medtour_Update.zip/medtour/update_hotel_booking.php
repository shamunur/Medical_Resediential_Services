<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);
$booking = null;
$update_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $hotel_name = $conn->real_escape_string($_POST['hotel_name']);
    $checkin_date = $conn->real_escape_string($_POST['checkin_date']);
    $checkin_time = $conn->real_escape_string($_POST['checkin_time']);
    $checkout_date = $conn->real_escape_string($_POST['checkout_date']);
    $num_guests = $conn->real_escape_string($_POST['num_guests']);
    $room_type = $conn->real_escape_string($_POST['room_type']);

    $sql = "UPDATE hotel_bookings SET 
            hotel_name='$hotel_name', 
            checkin_date='$checkin_date', 
            checkin_time='$checkin_time', 
            checkout_date='$checkout_date', 
            num_guests='$num_guests', 
            room_type='$room_type'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        $update_success = true;
    } else {
        echo "Error updating booking: " . $conn->error;
    }
}

$sql = "SELECT * FROM hotel_bookings WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $booking = $result->fetch_assoc();
} else {
    echo "No booking found";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hotel Booking</title>
    <style>
        /* Your CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #f9f9f9;
        }
        .container h2 {
            margin-top: 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        .form-group .back-button {
            background-color: #007bff;
        }
        .form-group .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Hotel Booking</h2>
        <?php if ($update_success): ?>
            <p>Booking updated successfully.</p>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="hotel_name">Hotel Name</label>
                <input type="text" id="hotel_name" name="hotel_name" value="<?= htmlspecialchars($booking['hotel_name']) ?>" required>
            </div>
            <div class="form-group">
                <label for="checkin_date">Check-in Date</label>
                <input type="date" id="checkin_date" name="checkin_date" value="<?= htmlspecialchars($booking['checkin_date']) ?>" required>
            </div>
            <div class="form-group">
                <label for="checkin_time">Check-in Time</label>
                <input type="time" id="checkin_time" name="checkin_time" value="<?= htmlspecialchars($booking['checkin_time']) ?>" required>
            </div>
            <div class="form-group">
                <label for="checkout_date">Check-out Date</label>
                <input type="date" id="checkout_date" name="checkout_date" value="<?= htmlspecialchars($booking['checkout_date']) ?>" required>
            </div>
            <div class="form-group">
                <label for="num_guests">Number of Guests</label>
                <input type="number" id="num_guests" name="num_guests" value="<?= htmlspecialchars($booking['num_guests']) ?>" required>
            </div>
            <div class="form-group">
                <label for="room_type">Room Type</label>
                <input type="text" id="room_type" name="room_type" value="<?= htmlspecialchars($booking['room_type']) ?>" required>
            </div>
            <div class="form-group">
                <button type="submit">Update Booking</button>
                <button type="button" class="back-button" onclick="window.location.href='view_admin_hotel.php'">Back</button>
            </div>
        </form>
    </div>
</body>
</html>
