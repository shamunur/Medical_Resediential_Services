<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['patient_id'])) {
    $patient_id = $_GET['patient_id'];

    // Delete record
    $sql = "DELETE FROM visa_assistance WHERE patient_id = '$patient_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Record deleted successfully";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "No patient ID provided.";
}
$conn->close();
?>
