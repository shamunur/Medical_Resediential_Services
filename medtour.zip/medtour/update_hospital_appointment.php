<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);
$appointment = null;
$update_success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $doctor_name = $conn->real_escape_string($_POST['doctor_name']);
    $hospital_name = $conn->real_escape_string($_POST['hospital_name']);
    $appointment_time = $conn->real_escape_string($_POST['appointment_time']);
    $appointment_date = $conn->real_escape_string($_POST['appointment_date']);
    $cancer_type = $conn->real_escape_string($_POST['cancer_type']);
    $treatment_plan = $conn->real_escape_string($_POST['treatment_plan']);

    $sql = "UPDATE hospital_appointments SET 
            doctor_name='$doctor_name', 
            hospital_name='$hospital_name', 
            appointment_time='$appointment_time', 
            appointment_date='$appointment_date', 
            cancer_type='$cancer_type',
            treatment_plan='$treatment_plan'
            WHERE id=$id";

    if ($conn->query($sql) === TRUE) {
        $update_success = true;
    } else {
        echo "Error updating appointment: " . $conn->error;
    }
}

$sql = "SELECT * FROM hospital_appointments WHERE id=$id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $appointment = $result->fetch_assoc();
} else {
    echo "No appointment found";
    exit;
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Hospital Appointment</title>
    <style>
        /* Your CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            background-color: #f9f9f9;
        }
        .container h2 {
            margin-top: 0;
        }
        .form-group {
            margin-bottom: 15px;
        }
        .form-group label {
            display: block;
            margin-bottom: 5px;
        }
        .form-group input, .form-group textarea {
            width: 100%;
            padding: 8px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }
        .form-group button {
            padding: 10px 15px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-group button:hover {
            background-color: #45a049;
        }
        .form-group .back-button {
            background-color: #007bff;
        }
        .form-group .back-button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Update Hospital Appointment</h2>
        <?php if ($update_success): ?>
            <p>Appointment updated successfully.</p>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="doctor_name">Doctor Name</label>
                <input type="text" id="doctor_name" name="doctor_name" value="<?= htmlspecialchars($appointment['doctor_name']) ?>" required>
            </div>
            <div class="form-group">
                <label for="hospital_name">Hospital Name</label>
                <input type="text" id="hospital_name" name="hospital_name" value="<?= htmlspecialchars($appointment['hospital_name']) ?>" required>
            </div>
            <div class="form-group">
                <label for="appointment_time">Appointment Time</label>
                <input type="time" id="appointment_time" name="appointment_time" value="<?= htmlspecialchars($appointment['appointment_time']) ?>" required>
            </div>
            <div class="form-group">
                <label for="appointment_date">Appointment Date</label>
                <input type="date" id="appointment_date" name="appointment_date" value="<?= htmlspecialchars($appointment['appointment_date']) ?>" required>
            </div>
            <div class="form-group">
                <label for="cancer_type">Cancer Type</label>
                <input type="text" id="cancer_type" name="cancer_type" value="<?= htmlspecialchars($appointment['cancer_type']) ?>" required>
            </div>
            <div class="form-group">
                <label for="treatment_plan">Treatment Plan</label>
                <input type="text" id="treatment_plan" name="treatment_plan" value="<?= htmlspecialchars($appointment['treatment_plan']) ?>" required>
            </div>
            <div class="form-group">
                <button type="submit">Update Appointment</button>
                <button type="button" class="back-button" onclick="window.location.href='view_admin_hospital.php'">Back</button>
            </div>
        </form>
    </div>
</body>
</html>
