<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$patient_id = intval($_GET['patient_id']);
$sql = "SELECT * FROM transport_bookings WHERE patient_id = $patient_id";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $data = $result->fetch_assoc();
    echo json_encode($data);
} else {
    echo json_encode([]);
}

$conn->close();
?>
