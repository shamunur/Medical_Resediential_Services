<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['patient_id'])) {
    $patient_id = $_GET['patient_id'];

    // Fetch current data
    $sql = "SELECT * FROM visa_assistance WHERE patient_id = '$patient_id'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
    } else {
        echo "No record found for patient ID: $patient_id";
        exit;
    }
} elseif (isset($_POST['patient_id'])) {
    // Update data
    $patient_id = $_POST['patient_id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $country = $_POST['country'];
    $passport_number = $_POST['passport_number'];
    $visa_type = $_POST['visa_type'];
    $purpose = $_POST['purpose'];
    $appointment_date = $_POST['appointment_date'];

    $sql = "UPDATE visa_assistance SET name='$name', email='$email', country='$country', passport_number='$passport_number', visa_type='$visa_type', purpose='$purpose', appointment_date='$appointment_date' WHERE patient_id='$patient_id'";

    if ($conn->query($sql) === TRUE) {
        echo "Record updated successfully";
    } else {
        echo "Error updating record: " . $conn->error;
    }
    $conn->close();
    exit;
} else {
    echo "No patient ID provided.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Patient Details - Medical Tourism Service</title>
    <style>
        /* Your CSS styles */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-image: url('visa.png');
            background-size: cover;
            background-position: center;
        }
        header {
            background-color: #333;
            color: #fff;
            padding: 10px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        .logo img {
            height: 50px;
            margin-right: 10px;
        }
        .name h1 {
            margin: 0;
        }
        nav ul {
            list-style-type: none;
            margin: 0;
            padding: 0;
            display: flex;
        }
        nav ul li {
            margin-right: 20px;
        }
        nav ul li a {
            color: #fff;
            text-decoration: none;
            font-weight: bold;
        }
        nav ul li a:hover {
            text-decoration: underline;
        }
        .container {
            margin: 50px auto;
            width: 80%;
            text-align: center;
        }
        form {
            background-color: rgba(255, 255, 255, 0.8);
            padding: 20px;
            border-radius: 10px;
        }
        form label {
            display: block;
            margin: 10px 0 5px;
        }
        form input[type="text"], form input[type="date"] {
            width: calc(100% - 20px);
            padding: 8px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        form .buttons {
            display: flex;
            justify-content: space-between;
        }
        form button {
            padding: 10px 20px;
            background-color: #4CAF50; /* Green */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        form button:hover {
            background-color: #45a049; /* Darker green */
        }
        form .back-button {
            background-color: #555; /* Gray */
        }
        form .back-button:hover {
            background-color: #333; /* Darker gray */
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">
            <img src="logo.png" alt="Medical Tourism Service Logo">
        </div>
        <div class="name">
            <h1>Medical Tourism Service</h1>
        </div>
        <nav>
            <ul>
                <li><a href="dashboard.php">Home</a></li>
                <li><a href="login_admin.php">Admin</a></li>
                <li><a href="login_user.php">User</a></li>
                <li><a href="services.php">Services</a></li>
                <li><a href="help.php">Help</a></li>
            </ul>
        </nav>
    </header>

    <div class="container">
        <h2>Update Patient Details</h2>
        <form method="POST" action="update.php">
            <input type="hidden" name="patient_id" value="<?php echo $row['patient_id']; ?>">
            <label for="name">Full Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $row['name']; ?>">
            <label for="email">Email:</label>
            <input type="text" id="email" name="email" value="<?php echo $row['email']; ?>">
            <label for="country">Country:</label>
            <input type="text" id="country" name="country" value="<?php echo $row['country']; ?>">
            <label for="passport_number">Passport Number:</label>
            <input type="text" id="passport_number" name="passport_number" value="<?php echo $row['passport_number']; ?>">
            <label for="visa_type">Visa Type:</label>
            <input type="text" id="visa_type" name="visa_type" value="<?php echo $row['visa_type']; ?>">
            <label for="purpose">Purpose of Visit:</label>
            <input type="text" id="purpose" name="purpose" value="<?php echo $row['purpose']; ?>">
            <label for="appointment_date">Appointment Date:</label>
            <input type="date" id="appointment_date" name="appointment_date" value="<?php echo $row['appointment_date']; ?>">
            <div class="buttons">
                <button type="submit">Update</button>
                <a href="javascript:history.back()" class="back-button">Back</a>
            </div>
        </form>
    </div>
</body>
</html>
