<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $patient_id = intval($_POST['patient_id']);
    $transport_type = $conn->real_escape_string($_POST['transport_type']);
    $pickup_location = $conn->real_escape_string($_POST['pickup_location']);
    $destination = $conn->real_escape_string($_POST['destination']);
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);

    $sql = "UPDATE transport_bookings SET 
            transport_type='$transport_type', 
            pickup_location='$pickup_location', 
            destination='$destination', 
            date='$date', 
            time='$time' 
            WHERE patient_id=$patient_id";

    if ($conn->query($sql) === TRUE) {
        echo "Transport booking updated successfully.";
    } else {
        echo "Error updating booking: " . $conn->error;
    }
}

$conn->close();
?>
