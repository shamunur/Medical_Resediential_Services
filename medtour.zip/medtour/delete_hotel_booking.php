<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mt_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$id = intval($_GET['id']);

$sql = "DELETE FROM hotel_bookings WHERE id=$id";

if ($conn->query($sql) === TRUE) {
    header("Location: view_admin_hotel.php");
    exit;
} else {
    echo "Error deleting booking: " . $conn->error;
}

$conn->close();
?>
