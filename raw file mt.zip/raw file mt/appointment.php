<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book An Appointment</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .appointment-container {
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 300px;
            max-width: 100%;
            text-align: center;
            padding: 20px;
        }

        .appointment-container h1 {
            color: #333;
            font-size: 24px;
            margin-bottom: 10px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-group label {
            display: block;
            text-align: left;
            margin-bottom: 5px;
        }

        .form-group input, .form-group select {
            width: 100%;
            padding: 8px;
            box-sizing: border-box;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        .form-group button {
            background-color: #4caf50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            width: 100%;
            margin-top: 10px;
        }
    </style>
</head>
<body>

<div class="appointment-container">
    <h1>Medical Tourism</h1>
    <h2>Book An Appointment</h2>
    <form class="appointment-form" action="save_appointment.php" method="post">
        <div class="form-group">
            <label for="patient-id">Patient ID:</label>
            <input type="text" id="patient-id" name="patient-id" required>
        </div>
        <div class="form-group">
            <label for="cancer-type">Cancer Type:</label>
            <input type="text" id="cancer-type" name="cancer-type" required>
        </div>
        <div class="form-group">
            <label for="select-city">Select City:</label>
            <select id="select-city" name="select-city" required>
                <option value="">Select City</option>
                <option value="Dhaka">Dhaka</option>
                <option value="Narsingdi">Narsingdi</option>
                <option value="Gazipur">Gazipur</option>
            </select>
        </div>
        <div class="form-group">
            <label for="hospital">Hospital:</label>
            <input type="text" id="hospital" name="hospital" required>
        </div>
        <div class="form-group">
            <label for="appointment-date">Appointment Date:</label>
            <input type="date" id="appointment-date" name="appointment-date" required>
        </div>
        <div class="form-group">
            <label for="patient-condition">Patient Condition:</label>
            <input type="text" id="patient-condition" name="patient-condition" required>
        </div>
        <div class="form-group">
            <label for="treatment-type">Treatment Type:</label>
            <input type="text" id="treatment-type" name="treatment-type" required>
        </div>
        <div class="form-group">
            <button type="submit">Submit</button>
        </div>
    </form>
    <p><a href="view_appointments.php">View Appointments</a></p>
</div>

</body>
</html>
