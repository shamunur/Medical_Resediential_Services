<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Services - Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        header, footer {
            background-color: #004F91;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-top: 0;
        }

        .services-list {
            list-style-type: none;
            padding: 0;
        }

        .services-list li {
            margin-bottom: 10px;
        }

        .services-list li a {
            display: block;
            padding: 10px;
            background-color: #004F91;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            transition: background-color 0.3s;
        }

        .services-list li a:hover {
            background-color: #002944;
        }

        footer {
            margin-top: 20px;
        }
    </style>
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->

        <div class="container">
            <h2>Our Services</h2>
            <ul class="services-list">
                <li><a href="visa.php">Visa Assistance</a></li>
                <li><a href="transportation.php">Transportation</a></li>
                <li><a href="hotels.php">Hotels</a></li>
                <li><a href="hospitals.php">Hospital List</a></li>
                <li><a href="locateus.php">Locate Us</a></li>
            </ul>
        </div>

    </div>
</body>
</html>
