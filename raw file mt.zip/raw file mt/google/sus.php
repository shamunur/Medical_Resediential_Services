<!DOCTYPE html>
<html>
<title> Sign in - Google Accounts </title>

<head>

</head>

<body>
    
    <center>
        <h2>
            <span style="color:rgb(35, 156, 255);">G<span>
                    <span style="color:rgb(255, 28, 28);">o</span>
                    <span style="color:rgb(255, 184, 77);">o</span>
                    <span style="color:rgb(20, 169, 255);">g</span>
                    <span style="color:rgb(0, 165, 8);">l</span>
                    <span style="color:red;">e</span>
        </h2>
        <h1><b>Create a Google Account</b></h1>
        <h4>Enter your name</h4>
        <form action="/sus.php">
            <label for="fname">First Name:</label><br>
            <input type="text" id="fname" name="fname"><br><br>
            <label for="lname">Last name:</label><br>
            <input type="text" id="lname" name="lname"><br><br>
            <input type="submit" value="next" style="background-color: #4285f4; color: white; border: none;">

            <br><br>


        </form>



        <span>
            <form action="/sus.php">
                <!--<label for="cars">Choose a car:</label> -->
                <select id="lang" name="lang">
                    <option value="eng">English</option>
                    <option value="hindi">Hindi</option>
                    <option value="urdu">Urdu</option>
                    <option value="spanish">Spanish</option>
                </select>

                &nbsp &nbsp  
                &nbsp
        </span>
        <span>Help</span>
        &nbsp
        <span>Privacy</span>
        &nbsp
        <span>Terms</span>
        &nbsp
    </center>

</body>


</html>