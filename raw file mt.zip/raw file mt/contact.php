<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        header, footer {
            background-color: #004F91;
            color: #FFFFFF;
            text-align: center;
            padding: 20px;
        }

        .contact-info {
            margin: 20px auto;
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: #f9f9f9;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            max-width: 800px; /* Limit width of contact info */
            margin-top: 20px; /* Add some top margin */
        }

        .dynamic-photos {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin-top: 20px;
        }

        .dynamic-photo {
            width: 30%;
            margin-bottom: 20px;
            border-radius: 5px;
            overflow: hidden;
        }

        .dynamic-photo img {
            width: 100%;
            height: auto;
        }
    </style>
</head>
<body>
    <!-- Include the dashboard header and navigation here -->
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->

        <div class="contact-info">
            <h2>Contact Information</h2>
            <p>Email: ratulrahman0340@gmail.com</p>
            <p>Phone: +8801627410612</p>
            <p>Address: 1840 Bamnartek, Uttara, Dhaka, Bangladesh</p>
        </div>

        <div class="dynamic-photos">
            <div class="dynamic-photo">
                <img src="evercare.png" alt="Dynamic Photo 1">
            </div>
            <div class="dynamic-photo">
                <img src="hotel.png" alt="Dynamic Photo 2">
            </div>
            <div class="dynamic-photo">
                <img src="airport.png" alt="Dynamic Photo 3">
            </div>
        </div>

        <footer>
            <p>Developed by Medical Tourism Team</p>
        </footer>
        <!-- Main content ends here -->
    </div>
</body>
</html>
