// timer.js

// Function to display the pop-up notification
function showNotification() {
    var popup = document.getElementById('popup');
    popup.style.display = 'block';
}

// Timer to show the pop-up after 30 seconds
setTimeout(showNotification, 30000);
