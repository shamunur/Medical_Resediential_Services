<!DOCTYPE html>
<html lang="en">
<head>
    <title>Medical Tourism</title>
    <link rel="stylesheet" href="dash.css">
    <script src="timer.js"></script> <!-- Link the JavaScript file -->
</head>
<body>

    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"> <button class="btn">Search</button></a>
            </div>

        </div> 
        <div class="content">
            <h1>We Are<br><span>Medical Tourism</span> <br>Are Here</h1>
            <p class="par">

Bangladesh is becoming a hotspot for medical tourism, offering top-notch healthcare services in<br> 
various specialties like cardiology, orthopedics, and ophthalmology at affordable rates. Patients<br> 
flock to the country to receive quality treatment from skilled professionals while enjoying the<br>
country's rich culture and scenic attractions.</p>

                <button class="cn"><a href="register_form.php">JOIN US</a></button>

                <div class="form">
                    <h2>Login Here</h2>
                    <input type="email" name="email" placeholder="Enter Email Here">
                    <input type="password" name="" placeholder="Enter Password Here">
                    <button class="btnn"><a href="login_form.php">Login</a></button>

                    <p class="link">Don't have an account<br>
                    <a href="register_form.php">Sign up </a> here</a></p>
                    <p class="liw">Visit</p>

                    <div class="icons">
                        <a href="facebook.php"><ion-icon name="logo-facebook"></ion-icon></a>
                        <a href="instagram.php"><ion-icon name="logo-instagram"></ion-icon></a>
                        <a href="twitter.php"><ion-icon name="logo-twitter"></ion-icon></a>
                        <a href="google.php"><ion-icon name="logo-google"></ion-icon></a>
                        <a href="skypee.php"><ion-icon name="logo-skype"></ion-icon></a>
                    </div>

                </div>
                    </div>
                </div>
        </div>
    </div>
    <script src="https://unpkg.com/ionicons@5.4.0/dist/ionicons.js"></script>
</body>
</html>
