<!DOCTYPE html>
<html>
    <head>
        <style>
            table,th,td {
            border:1px solid black;
            }
        </style>
    </head>
    <body>
        <center>
            <h1>Product Management System</h1>
            <?php
            $servername="localhost";
            $username="root";
            $password="";
            $db_name="db_ratul";
            $conn=mysqli_connect($servername, $username, $password, $db_name);
            if(!$conn) {
                echo "Not Connected";
            }
            else {
                echo "connected";
            }
            $sql="SELECT * FROM tb_product";
            $result=$conn->query($sql);

            if($result->num_rows>0) {

                echo
                "<table>
                <tr>
                <th> p_id </th>
                <th> p_name </th>
                <th> price </th>
                </tr>";
                while($row=$result->fetch_assoc()) {

                    echo "<tr> <td>".$row["p_id"]. "</td><td>".$row["p_name"]. "</td><td>".$row["price"]. "</td>";
                }
                echo "</table>";
            }

            else {
                echo "0 Results";
            }
            $conn->close();
            ?>
                <br><br><br><br><br><br>
        </center>
    </body>
</html>