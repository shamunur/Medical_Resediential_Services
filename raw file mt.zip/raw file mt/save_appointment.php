<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = ""; 
    $dbname = "viewap";

    $conn = new mysqli($servername, $username, $password, $dbname);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $sql = "INSERT INTO appointments (patient_id, cancer_type, city, hospital, appointment_date, patient_condition, treatment_type)
            VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssss", $patient_id, $cancer_type, $city, $hospital, $appointment_date, $patient_condition, $treatment_type);

    $patient_id = $_POST['patient-id'];
    $cancer_type = $_POST['cancer-type'];
    $city = $_POST['select-city'];
    $hospital = $_POST['hospital'];
    $appointment_date = $_POST['appointment-date'];
    $patient_condition = $_POST['patient-condition'];
    $treatment_type = $_POST['treatment-type'];

    if ($stmt->execute()) {
        header("Location: view_appointments.php");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
