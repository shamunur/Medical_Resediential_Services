<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Facilities - Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            /* Remove background-color */
            overflow: hidden; /* Ensure the blur doesn't create scrollbars */
        }

        /* New style for the blurred background */
        .blur-background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1; /* Place it behind other content */
            filter: blur(10px); /* Adjust the blur effect */
            background-image: url('privacy.jpg'); /* Add the path to your image */
            background-size: cover; /* Ensure the image covers the entire viewport */
            background-position: center; /* Center the image */
        }

        header, footer {
            background-color: #004F91;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Use rgba to add transparency */
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            position: relative; /* Ensure it's positioned relative to the body */
        }

        h1 {
            margin-top: 0;
        }

        p {
            line-height: 1.6;
        }

        footer {
            margin-top: 20px;
        }

        .dynamic-content {
            transform: scale(1.1);
            transition: transform 0.5s;
        }

        .dynamic-content:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Add the blurred background div -->
    <div class="blur-background"></div>

    <!-- Include the dashboard header and navigation here -->
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->
        <div class="container dynamic-content">
            <h1>Privacy Policy</h1>
            <p>At Medical Tourism, accessible from www.medicaltourism.com, one of our main priorities is the privacy of our visitors. This Privacy Policy document contains types of information that is collected and recorded by Medical Tourism and how we use it.</p>
        
            <h2>Log Files</h2>
            <p>Medical Tourism follows a standard procedure of using log files.</p>
        </div>
        <!-- Main content ends here -->
    </div>

    <footer>
        <p>Developed by Medical Tourism Team</p>
    </footer>
</body>
</html>
