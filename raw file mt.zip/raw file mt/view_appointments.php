<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Appointments</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>View Appointments</h2>

<table>
    <thead>
        <tr>
            <th>Patient ID</th>
            <th>Cancer Type</th>
            <th>City</th>
            <th>Hospital</th>
            <th>Appointment Date</th>
            <th>Patient Condition</th>
            <th>Treatment Type</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $servername = "localhost";
        $username = "root";
        $password = ""; // Assuming no password is set
        $dbname = "viewap";

        $conn = new mysqli($servername, $username, $password, $dbname);

        if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
        }

        $sql = "SELECT * FROM appointments";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>" . $row['patient_id'] . "</td>";
                echo "<td>" . $row['cancer_type'] . "</td>";
                echo "<td>" . $row['city'] . "</td>";
                echo "<td>" . $row['hospital'] . "</td>";
                echo "<td>" . $row['appointment_date'] . "</td>";
                echo "<td>" . $row['patient_condition'] . "</td>";
                echo "<td>" . $row['treatment_type'] . "</td>";
                echo "</tr>";
            }
        } else {
            echo "<tr><td colspan='7'>No Appointment History Found</td></tr>";
        }

        $conn->close();
        ?>
    </tbody>
</table>

</body>
</html>
