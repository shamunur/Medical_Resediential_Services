<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Facebook Information - Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        header, footer {
            background-color: #004F91;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-top: 0;
        }

        .social-info {
            margin-top: 20px;
        }

        .social-info p {
            margin-bottom: 10px;
        }

        footer {
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <!-- Include the dashboard header and navigation here -->
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->


        <div class="container">
            <h2>Twitter Information</h2>
        <div class="social-info">
            <p>Follow us on Twitter for updates and news:</p>
            <p>Twitter Profile: <a href="https://twitter.com/medicalTourism" target="_blank">medicalTourism</a></p>
        </div>
        </div>
        <!-- Main content ends here -->

        <footer>
            <p>Developed by Medical Tourism Team</p>
        </footer>
    </div>
</body>
</html>
