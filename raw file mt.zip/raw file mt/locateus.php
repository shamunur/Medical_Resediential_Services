<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Facilities - Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        header, footer {
            background-color: #004F91;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-top: 0;
        }

        p {
            line-height: 1.6;
        }

        footer {
            margin-top: 20px;
        }

        .dynamic-content {
            transform: scale(1.1);
            transition: transform 0.5s;
        }

        .dynamic-content:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Include the dashboard header and navigation here -->
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->
        <div class="container dynamic-content">
              <div class="map">
            <iframe src="https://maps.app.goo.gl/DdA6P4iZi9sWWwdT9" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
        </div>
        <div class="address">
            <h2>Our Location</h2>
            <p>Medical Tourism Facility</p>
            <p>1840 Bamnartek Road</p>
            <p>Uttara Sector 10,Dhaka</p>
            <p>Bangladesh</p>
        </div>
        <div class="contact-info">
            <h2>Contact Information</h2>
            <p>Email: ratulrahman0340@gmail.com</p>
            <p>Phone: +8801627410612</p>
        </div>
    </div>

    <footer>
        <p>Developed by Medical Tourism Team</p>
    </footer>

        </div>
        <!-- Main content ends here -->
    </div>

</body>
</html>
