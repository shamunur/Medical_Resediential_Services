<?php

$conn = mysqli_connect('localhost','root','','user_db');

?>
<?php
session_start();

// create a connnection 
$con = mysqli_connect("localhost", "root", "", "test");
$username = $_POST['username'];
$password = $_POST['password'];
// insert data into database
$sql = "SELECT username, pass FROM customer WHERE username=?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "s", $username);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
mysqli_stmt_close($stmt);

// verifying user login
$row = mysqli_fetch_assoc($result);
if($row['username'] == $username && $row['pass'] == $password) {
    $_SESSION['username'] = $row['username'];
    $_SESSION['password'] = $row['pass'];
    header("Location: dashboard.php"); // redirects to the new page
} else {
    echo "Login failed";
}
?>