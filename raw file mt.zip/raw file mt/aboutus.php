<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hotel Facilities - Medical Tourism</title>
    <link rel="stylesheet" href="dash.css"> <!-- Link to your CSS file -->
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f2f2f2;
        }

        header, footer {
            background-color: #004F91;
            color: white;
            text-align: center;
            padding: 20px;
        }

        .container {
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            margin-top: 0;
        }

        p {
            line-height: 1.6;
        }

        footer {
            margin-top: 20px;
        }

        .dynamic-content {
            transform: scale(1.1);
            transition: transform 0.5s;
        }

        .dynamic-content:hover {
            transform: scale(1.05);
        }
    </style>
</head>
<body>
    <!-- Include the dashboard header and navigation here -->
    <div class="main">
        <div class="navbar">
            <div class="icon">
                <h2 class="logo">Medical Tourism BD</h2>
            </div>

            <div class="menu">
                <ul>
                    <li><a href="dashboard.php">HOME</a></li>
                    <li><a href="aboutus.php">ABOUT</a></li>
                    <li><a href="services.php">SERVICES</a></li>
                    <li><a href="privacy.php">PRIVACY POLICY</a></li>
                    <li><a href="contact.php">CONTACT</a></li>
                </ul>
            </div>

            <div class="search">
                <input class="srch" type="search" name="" placeholder="Type To text">
                <a href="#"><button class="btn">Search</button></a>
            </div>
        </div> 
        <!-- Main content starts here -->
        <div class="container dynamic-content">
          <h1>Welcome to Medical Tourism BD</h1>
            <p>Medical Tourism BD is your one-stop destination for all medical needs in Bangladesh. Established in 2024, we aim to provide top-notch medical services to both locals and international patients.</p>
            <p>Our services include:</p>
            <ul>
                <li>Access to the best hospitals and medical facilities in Bangladesh</li>
                <li>Assistance with medical visa procedures</li>
                <li>Arrangement of accommodations and travel for patients and their families</li>
                <li>Specialized medical treatments in various fields such as cardiology, orthopedics, and ophthalmology</li>
            </ul>
            <p>We prioritize patient satisfaction and safety, ensuring that all services provided through Medical Tourism BD meet the highest standards of quality and professionalism.</p>
            <p>For inquiries and appointments, please contact us or visit our office. We look forward to assisting you in your medical journey.</p>
               
           

    </div>

    <footer>
        <p>Developed by Medical Tourism Team</p>
    </footer>

        </div>
        <!-- Main content ends here -->
    </div>

</body>
</html>
